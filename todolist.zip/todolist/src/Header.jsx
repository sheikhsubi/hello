import React from "react";

function Header(){
    return(
        <div className="headingarea">
            <h1 className="headingtext">TO DO LIST</h1>
            </div>
           
    );
}
export default Header;